# Hackathon


![alt text](image-1.png)

**Resource** - a file, database query, (like a get request) or anything the LLM can use for context
**Tool** - is like a POST request

- use this to run -> npx expo start

### To Do
need to update useMcpApi with the MCP server endpoint


### Demo

#### Web

![alt text](image-3.png)

#### Android

![alt text](image-2.png)