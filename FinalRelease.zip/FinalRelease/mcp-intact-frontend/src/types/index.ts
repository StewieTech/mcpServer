export interface Prompt {
    text: string;
}

export interface Response {
    message: string;
}